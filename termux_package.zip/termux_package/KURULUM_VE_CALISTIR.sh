#!/bin/bash
# ============================================================
#  ÇekirdekNetwork Minecraft Video - Termux Kurulum & Render
# ============================================================

echo "=== Paketler kuruluyor ==="
pkg update -y
pkg install -y python ffmpeg

echo "=== Python kütüphaneleri ==="
pip install pillow --break-system-packages 2>/dev/null || pip install pillow

echo "=== Türkçe TTS sesi üretiliyor ==="
python scripts/narrate.py project.json --language tr

echo "=== Video render ediliyor (720p, 24fps) ==="
python scripts/studio.py project-voiced.json \
  --module scenes.py \
  --out output \
  --width 720 \
  --fps 24

echo ""
echo "=== TAMAMLANDI ==="
echo "Video: output/video.mp4"
