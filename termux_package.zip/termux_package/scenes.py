"""Minecraft motion graphics - sade, donmasız, profesyonel"""
import math, sys
sys.path.insert(0, '/mnt/skills/plugins/kare-ustasi/scripts')
from studio import Canvas, ease, BASE_W, BASE_H

BG     = '#0A0F1A'
GREEN  = '#00FF88'
DGREEN = '#003322'
CYAN   = '#00E5FF'
YELLOW = '#FFD700'
WHITE  = '#EFFFFF'
GRAY   = '#445566'
CARD   = '#111B2E'
DARK   = '#070D18'

def e(t):
    t = max(0.0, min(1.0, t))
    return t*t*(3-2*t)

def lerp(a, b, t):
    return a + (b-a)*max(0.0, min(1.0, t))

def gt(c, txt, x, y, sz=40, col=GREEN):
    for ox,oy in [(-2,-2),(2,-2),(-2,2),(2,2)]:
        c.text(txt, x+ox, y+oy, size=sz, fill='#000800')
    c.text(txt, x, y, size=sz, fill=col)

def safe_rect(c, x0, y0, x1, y1, **kw):
    if x1 > x0 and y1 > y0:
        c.d.rectangle([x0,y0,x1,y1], **kw)

def safe_rrect(c, x0, y0, x1, y1, radius=10, **kw):
    if x1 > x0+2 and y1 > y0+2:
        c.d.rounded_rectangle([x0,y0,x1,y1], radius=radius, **kw)

def safe_ellipse(c, x0, y0, x1, y1, **kw):
    if x1 > x0 and y1 > y0:
        c.d.ellipse([x0,y0,x1,y1], **kw)

# ─── SAHNE 1 ──────────────────────────────────────────────────────────────────
def scene1(c, t, d, s, p):
    c.d.rectangle([0,0,BASE_W,BASE_H], fill=BG)

    # Başlık
    ty = int(lerp(-40, 80, e(t/0.5)))
    safe_rrect(c, 40, ty-28, 680, ty+28, radius=14, fill=DGREEN, outline=GREEN, width=2)
    gt(c, '⚡ ÇEKİRDEK NETWORK', 360, ty, sz=28, col=GREEN)

    # Telefon
    PX,PY,PW,PH = 100,180,520,840
    safe_rrect(c, PX,PY,PX+PW,PY+PH, radius=30, fill=CARD, outline=GREEN, width=3)
    SX,SY,SW = PX+15,PY+30,PW-30
    safe_rrect(c, SX,SY,SX+SW,SY+PH-60, radius=16, fill=DARK)

    # MC başlık
    safe_rrect(c, SX+5,SY+5,SX+SW-5,SY+65, radius=12, fill='#5D9C3A')
    gt(c, 'MINECRAFT', SX+SW//2, SY+35, sz=30, col=YELLOW)

    # Çok Oyunculu
    safe_rrect(c, SX+20,SY+80,SX+SW-20,SY+135, radius=8, fill='#1A3A1A', outline=GREEN, width=2)
    c.text('ÇOK OYUNCULU', SX+SW//2, SY+107, size=24, fill=GREEN)

    # Sunucu Ekle butonu
    bp = e((t-1.0)/0.4)
    btn_col = GREEN if bp > 0.5 else GRAY
    safe_rrect(c, SX+30,SY+155,SX+SW-30,SY+205, radius=10,
               fill=DGREEN if bp>0.5 else '#161E2A', outline=btn_col, width=2)
    c.text('+ SUNUCU EKLE', SX+SW//2, SY+180, size=22, fill=btn_col)

    # Tıklama dalgası
    if 1.5 < t < 2.3:
        rp = (t-1.5)/0.8
        rr = int(rp*50)
        cx2,cy2 = SX+SW//2, SY+180
        safe_ellipse(c, cx2-rr,cy2-rr,cx2+rr,cy2+rr, outline=GREEN, width=max(1,int(3*(1-rp))))

    # IP yazma
    if t > 1.8:
        safe_rrect(c, SX+15,SY+220,SX+SW-15,SY+270, radius=8, fill='#0A1520', outline=CYAN, width=2)
        c.text('Sunucu Adresi', SX+SW//2, SY+233, size=15, fill=GRAY)
        full = 'CekirdekNetwork.aternos.me'
        chars = int(len(full)*min((t-2.0)/2.5, 1.0)) if t>2.0 else 0
        cur = '|' if int(t*3)%2==0 else ''
        gt(c, full[:chars]+cur, SX+SW//2, SY+254, sz=18, col=CYAN)

    # Bağlan butonu
    if t > 4.5:
        bp2 = e((t-4.5)/0.5)
        safe_rrect(c, SX+50, SY+285, SX+SW-50, SY+335, radius=20, fill=GREEN)
        c.text('BAĞLAN', SX+SW//2, SY+310, size=26, fill='#001100')

# ─── SAHNE 2 ──────────────────────────────────────────────────────────────────
def scene2(c, t, d, s, p):
    c.d.rectangle([0,0,BASE_W,BASE_H], fill=BG)

    # Bağlanıyor (ilk 1 sn)
    if t < 1.0:
        cp = e(t/1.0)
        c.text('Sunucuya Bağlanıyor...', 360, 540, size=32, fill=CYAN)
        bw = int(500*cp)
        safe_rrect(c, 110,590,610,618, radius=10, fill=GRAY)
        if bw > 2:
            safe_rrect(c, 110,590,110+bw,618, radius=10, fill=GREEN)
        for i in range(3):
            dc = GREEN if int(t*4+i)%2==0 else GRAY
            safe_ellipse(c, 280+i*45,650,310+i*45,680, fill=dc)
        return

    # Popup açılıyor
    pp = e(min((t-1.0)/0.5, 1.0))
    PW = int(560*pp)
    PH = int(600*pp)
    if PW < 20 or PH < 20:
        return
    PX = 360 - PW//2
    PY = int(lerp(500, 300, pp))

    # Dış parlaklık
    for gi in range(3,0,-1):
        gr = gi*12
        try:
            c.d.rounded_rectangle([PX-gr,PY-gr,PX+PW+gr,PY+PH+gr],
                                   radius=28+gr, outline=GREEN, width=max(1,2-gi//2))
        except: pass

    # Popup gövde
    safe_rrect(c, PX,PY,PX+PW,PY+PH, radius=24, fill=CARD, outline=GREEN, width=3)

    # Yeşil başlık — DÜZELTME: min() ile y0<y1 garantisi
    hdr_h = max(42, int(80*pp))
    safe_rrect(c, PX,PY,PX+PW,PY+hdr_h, radius=24, fill=DGREEN)
    safe_rect(c, PX,PY+hdr_h-20,PX+PW,PY+hdr_h, fill=DGREEN)

    # TEBRİKLER!
    tsz = max(10, int(48*pp))
    pulse = 1+0.06*math.sin(t*7)
    gt(c, 'TEBRİKLER! 🎉', 360, PY+hdr_h//2, sz=int(tsz*pulse), col=YELLOW)

    # Kupa ikonu
    if pp > 0.5:
        tx,ty2 = 360, PY+int(140*pp)
        ts = max(6, int(28*pp))
        safe_rrect(c, tx-ts*2,ty2-ts*2,tx+ts*2,ty2+ts, radius=ts//2, fill=YELLOW)
        safe_rect(c, tx-ts,ty2+ts,tx+ts,ty2+ts*2, fill=YELLOW)
        safe_rect(c, tx-ts*2,ty2+ts*2,tx+ts*2,ty2+ts*2+max(4,ts//3), fill=YELLOW)

    # Alt metin
    if t > 1.5:
        msz = max(8, int(30*pp))
        c.text('Play Kod Kazandın! 🎮', 360, PY+int(240*pp), size=msz, fill=WHITE)

    # Kod kutusu
    if t > 2.0:
        kp = e((t-2.0)/0.5)
        KW = max(20, int(440*pp*kp))
        KH = max(10, int(65*pp))
        KX = 360-KW//2
        KY = PY+int(300*pp)
        safe_rrect(c, KX,KY,KX+KW,KY+KH, radius=10, fill=DARK, outline=GREEN, width=2)
        ksz = max(10, int(26*pp))
        gt(c, 'MC-2024-XXXX-FREE', 360, KY+KH//2, sz=ksz, col=GREEN)

    # Yıldız parçacıkları
    if t > 1.2:
        burst = min((t-1.2)/0.8, 1.0)
        for i in range(6):
            ang = i*math.pi/3 + t*0.8
            sr = int(burst*70*pp)
            sx = 360+int(sr*math.cos(ang))
            sy2 = PY+hdr_h//2+int(sr*math.sin(ang)*0.4)
            safe_ellipse(c, sx-5,sy2-5,sx+5,sy2+5, fill=YELLOW)

# ─── SAHNE 3 ──────────────────────────────────────────────────────────────────
def scene3(c, t, d, s, p):
    c.d.rectangle([0,0,BASE_W,BASE_H], fill=BG)

    # Faz 1: Kod zoom (t<2)
    if t < 2.0:
        zp = e(t/1.5)
        zw = max(80, int(lerp(380, 540, zp)))
        zh = 70
        zx = 360-zw//2
        zy = 420
        for gi in range(4,0,-1):
            gr = gi*8
            try:
                c.d.rounded_rectangle([zx-gr,zy-gr,zx+zw+gr,zy+zh+gr],
                                       radius=14+gr, outline=GREEN, width=max(1,2-gi//2))
            except: pass
        safe_rrect(c, zx,zy,zx+zw,zy+zh, radius=12, fill=DARK, outline=GREEN, width=3)
        gt(c, 'MC-2024-XXXX-FREE', 360, zy+35, sz=28, col=GREEN)
        if t > 1.0:
            cp2 = min((t-1.0)/0.6, 1.0)
            c.text('📋 Kopyalandı!', 360, zy-45, size=30, fill=YELLOW)
            for i in range(5):
                px2 = zx+int(zw*(i/4))
                py2 = zy-int(cp2*55)
                cr = max(2,int(5*(1-cp2)))
                safe_ellipse(c, px2-cr,py2-cr,px2+cr,py2+cr, fill=GREEN)
        return

    # Faz 2: Play Store
    sp = e(min((t-2.0)/0.6, 1.0))
    ox = int(lerp(BASE_W, 0, sp))
    safe_rect(c, ox,0,ox+BASE_W,BASE_H, fill='#F2F2F2')
    safe_rect(c, ox,0,ox+BASE_W,95, fill='#FFFFFF')
    c.d.line([(ox,95),(ox+BASE_W,95)], fill='#DDDDDD', width=2)
    c.text('▶ Google Play', ox+360, 48, size=32, fill='#1A73E8')
    safe_rrect(c, ox+30,110,ox+690,165, radius=25, fill='#EEEEEE')
    c.text('🔍  Minecraft', ox+360, 137, size=24, fill='#5F6368')

    CY = 185
    safe_rrect(c, ox+20,CY,ox+700,CY+290, radius=16, fill='#FFFFFF', outline='#E0E0E0', width=1)
    IX,IY,IS = ox+45,CY+20,95
    safe_rrect(c, IX,IY,IX+IS,IY+IS, radius=18, fill='#5D9C3A')
    fs = IS//4
    safe_rect(c, IX+fs,IY+fs,IX+fs+16,IY+fs+16, fill='#111111')
    safe_rect(c, IX+IS-fs-16,IY+fs,IX+IS-fs,IY+fs+16, fill='#111111')
    my = IY+IS*2//3
    safe_rect(c, IX+fs,my,IX+IS-fs,my+9, fill='#111111')

    c.text('Minecraft', ox+230, CY+42, size=27, fill='#202124')
    c.text('Mojang Studios', ox+230, CY+74, size=19, fill='#5F6368')
    c.text('★★★★★  4.6', ox+230, CY+100, size=18, fill='#FBBC04')
    c.text('₺79,99', ox+230, CY+126, size=22, fill='#202124')
    safe_rrect(c, ox+140,CY+155,ox+660,CY+205, radius=10, fill='#E8F5E9', outline='#4CAF50', width=2)
    c.text('Promo: MC-2024-XXXX-FREE', ox+400, CY+180, size=19, fill='#2E7D32')

    BTY = CY+220
    if t < 4.0:
        safe_rrect(c, ox+150,BTY,ox+570,BTY+55, radius=28, fill='#1A73E8')
        c.text('İNDİR', ox+360, BTY+27, size=26, fill='#FFFFFF')
    elif t < 5.5:
        prg = min((t-4.0)/1.5, 1.0)
        bw2 = max(10, int(prg*420))
        safe_rrect(c, ox+150,BTY,ox+570,BTY+55, radius=28, fill='#E0E0E0')
        safe_rrect(c, ox+150,BTY,ox+150+bw2,BTY+55, radius=28, fill='#4CAF50')
        c.text('İndiriliyor...', ox+360, BTY+27, size=22, fill='#FFFFFF')
    else:
        safe_rrect(c, ox+150,BTY,ox+570,BTY+55, radius=28, fill='#4CAF50')
        c.text('✓  İNDİRİLDİ', ox+360, BTY+27, size=24, fill='#FFFFFF')
        rp3 = min((t-5.5)/0.6, 1.0)
        rr3 = int(rp3*80)
        if rr3 > 0:
            safe_ellipse(c, ox+360-rr3,BTY+27-rr3,ox+360+rr3,BTY+27+rr3,
                        outline='#4CAF50', width=max(1,int(3*(1-rp3))))

def draw(c, t, d, s, p):
    visual = s.get('visual','')
    if   visual == 'scene1': scene1(c,t,d,s,p)
    elif visual == 'scene2': scene2(c,t,d,s,p)
    elif visual == 'scene3': scene3(c,t,d,s,p)
    else:
        c.d.rectangle([0,0,BASE_W,BASE_H], fill=BG)
        c.text('?', 360, 640, size=60, fill=GREEN)
